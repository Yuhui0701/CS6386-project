
function loy (){
    let url='http://127.0.0.1:8000/api/data/const1'
    $.get(url,item=>{
        var myChart = echarts.init(document.querySelector(".boxa3"));
        // 配置项
    var options = {
        title: {
          text: 'Age Group - Order Counts'
        },
        tooltip: {
          trigger: 'axis'
        },
        xAxis: {
          type: 'category',
          data: item.age_groups
        },
        yAxis: {
          type: 'value'
        },
        series: [{
          name: 'Order Counts',
          type: 'line',
          data: item.order_counts
        }]
      };
  
      // 渲染图表
      myChart.setOption(options);
      
 })}

 function predata(){
    // 基于准备好的dom，初始化echarts实例
    let url='http://127.0.0.1:8000/api/data/const1'
    $.get(url,item=>{
    var myChart = echarts.init(document.querySelector(".boxa3"));
  
    option = {
      tooltip: {
        trigger: "item",
        formatter: "{a} <br/>{b}: {c} ({d}%)",
        position: function(p) {
          //其中p为当前鼠标的位置
          return [p[0] + 10, p[1] - 10];
        }
      },
      legend: {
        top: "90%",
        itemWidth: 10,
        itemHeight: 10,
        data: item.gender_groups,
        textStyle: {
          color: "rgba(255,255,255,.5)",
          fontSize: "12"
        }
      },
      series: [
        {
          name: "xxx分布",
          type: "pie",
          center: ["50%", "42%"],
          radius: ["40%", "60%"],
          color: [
            "#065aab",
            "#066eab",
            "#0682ab",
            "#0696ab",
            "#06a0ab",
            "#06b4ab",
            "#06c8ab",
            "#06dcab",
            "#06f0ab"
          ],
          label: { show: false },
          labelLine: { show: false },
          data:
            item.counts

  
        }
      ]
    };
  
    // 使用刚指定的配置项和数据显示图表。
    myChart.setOption(option);
  
  })}